/*
 * (C) 2011, Andy Georges
 */
package be.ugent.csl.StepCounter;

class SimpleThresholdDetector implements StepDetection {

	@Override
	public void addData(long timestamp, double xAccell, double yAccell,
			double zAccell) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getSteps() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
}